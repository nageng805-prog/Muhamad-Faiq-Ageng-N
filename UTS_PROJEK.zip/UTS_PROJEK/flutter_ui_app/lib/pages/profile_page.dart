import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Profil")),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: AssetImage('flutter_ui_app/assets/profile.jpg'),
            ),
            SizedBox(height: 15),
            Text(
              "Muhamad Faiq Ageng NUgroho",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            Text("NIM: 24670043"),
            Text("Email: nageng805@gmail.com"),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Prodi: Informatika"),
                SizedBox(width: 10),
                Text("Semester: 3"),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Kembali ke Dashboard"),
            ),
          ],
        ),
      ),
    );
  }
}
