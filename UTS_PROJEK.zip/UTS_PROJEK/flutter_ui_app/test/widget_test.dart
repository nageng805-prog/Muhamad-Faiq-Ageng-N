import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_ui_app/main.dart';

void main() {
  testWidgets('Halaman login muncul dengan benar', (WidgetTester tester) async {
    await tester.pumpWidget(MyApp());

    expect(find.text('Selamat Datang'), findsOneWidget);
    expect(find.text('Login'), findsOneWidget);
  });
}