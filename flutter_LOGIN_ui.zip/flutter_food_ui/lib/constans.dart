import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Color whiteColor = Color(0xFFFFFFFF);
Color textColor = Color(0xFFFFFFFF);
Color secondaryTextColor = Color(0xffffffff);
Color buttonColor = Color(0xffffffff);
Color praimeryButtonColor = Color.fromARGB(255, 165, 81, 81);
Color tncButtonColor = Color(0xFFFFFFFF);
Color greyColor = Colors.grey;

TextStyle WhiteTextStyle = GoogleFonts.dmSans(color: whiteColor);
TextStyle textTextStyle = GoogleFonts.dmSans(color: textColor);
TextStyle secondaryTextStyle = GoogleFonts.dmSans(color: secondaryTextColor);
TextStyle tncTextStyle = GoogleFonts.dmSans(color: tncButtonColor);
TextStyle greyTextStyle = GoogleFonts.dmSans(color: greyColor);

FontWeight bold = FontWeight.bold;
