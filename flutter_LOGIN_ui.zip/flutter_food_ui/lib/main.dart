// lib/main.dart
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

/* ---------- Simple constants (dibuat local supaya file standalone) ---------- */
const Color kBackground = Color(0xFF5892AD);
const Color kWhite = Colors.white;
const Color kButton = Color(0xFF0B77B5);
const Color kAccent = Color(0xFF2D6A7D);
const Color kGrey = Colors.grey;

const FontWeight kBold = FontWeight.w700;
const FontWeight kSemiBold = FontWeight.w600;

/* Text styles */
final TextStyle textTextStyle = const TextStyle(
  color: Colors.black,
  fontSize: 14,
).copyWith();

final TextStyle whiteTextStyle = const TextStyle(
  color: Colors.white,
  fontSize: 14,
);

final TextStyle secondaryTextStyle = const TextStyle(
  color: Colors.white70,
  fontSize: 12,
);

final TextStyle greyTextStyle = const TextStyle(
  color: Colors.grey,
  fontSize: 12,
);

final TextStyle tncTextStyle = const TextStyle(
  color: Colors.blueAccent,
  fontSize: 12,
);

/* ---------- App ---------- */
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // debugShowCheckedModeBanner: false,
      title: 'Login Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const LoginPage(),
    );
  }
}

/* ---------- Login Page (Standalone, fixed) ---------- */
class LoginPage extends StatelessWidget {
  const LoginPage({Key? key}) : super(key: key);

  // Note: In a real app you should use Controllers inside a StatefulWidget.
  @override
  Widget build(BuildContext context) {
    // controllers (for demonstration; in stateless keep local TextFields if desired)
    final TextEditingController emailController = TextEditingController();
    final TextEditingController passwordController = TextEditingController();

    return Scaffold(
      backgroundColor: kBackground,
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Title
                Text(
                  "Welcome Back",
                  style: textTextStyle.copyWith(
                    fontSize: 30,
                    fontWeight: kBold,
                    color: kWhite,
                  ),
                ),
                const SizedBox(height: 11),
                Text("Lorem ipsum dolor sit amet", style: secondaryTextStyle),
                const SizedBox(height: 64),

                // Email & Password block
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Email label
                    Text(
                      "Email",
                      style: textTextStyle.copyWith(
                        fontSize: 12,
                        fontWeight: kSemiBold,
                        color: kWhite,
                      ),
                    ),
                    const SizedBox(height: 10),
                    // Email field container
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: kWhite,
                      ),
                      child: TextField(
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "muhamadfaiq@gmail.com",
                          hintStyle: textTextStyle.copyWith(
                            fontSize: 12,
                            color: Colors.black.withOpacity(0.6),
                          ),
                          prefixIcon: const Icon(Icons.email),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 17,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 15),

                    // Password label
                    Text(
                      "Password",
                      style: textTextStyle.copyWith(
                        fontSize: 12,
                        fontWeight: kSemiBold,
                        color: kWhite,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: kWhite,
                      ),
                      child: TextField(
                        controller: passwordController,
                        obscureText: true,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "********",
                          hintStyle: textTextStyle.copyWith(
                            fontSize: 12,
                            color: Colors.black.withOpacity(0.6),
                          ),
                          prefixIcon: const Icon(Icons.lock),
                          suffixIcon: const Icon(Icons.visibility_off),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 17,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // Remember me & Forgot password row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            color: kButton,
                            borderRadius: BorderRadius.circular(5),
                          ),
                        ),
                        const SizedBox(width: 15),
                        Text("Remember me", style: greyTextStyle),
                      ],
                    ),
                    Text(
                      "Forgot Password?",
                      style: textTextStyle.copyWith(
                        fontSize: 12,
                        color: kWhite,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 32),

                // LOGIN button
                Container(
                  width: double.infinity,
                  height: 50,
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: kButton),
                    onPressed: () {
                      // basic validation
                      final email = emailController.text.trim();
                      final pass = passwordController.text.trim();
                      if (email.isEmpty || pass.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Email dan password tidak boleh kosong',
                            ),
                          ),
                        );
                        return;
                      }
                      // proceed (dummy)
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Logged in as: $email'),
                          duration: const Duration(seconds: 1),
                        ),
                      );
                    },
                    child: Text(
                      "LOGIN",
                      style: whiteTextStyle.copyWith(
                        fontWeight: kSemiBold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),

                // Sign in with Google
                Container(
                  width: double.infinity,
                  height: 50,
                  margin: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 19,
                  ),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: kAccent),
                    onPressed: () {
                      // dummy action
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Google sign-in')),
                      );
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // use an icon instead of external network image to avoid CORS or load issues
                        Image.network(
                          'https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg',
                          height: 20,
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(Icons.g_mobiledata, size: 20);
                          },
                        ),
                        const SizedBox(width: 12),
                        Text(
                          "Sign in with Google",
                          style: whiteTextStyle.copyWith(
                            fontWeight: kSemiBold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Sign up text
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "You don't have an account yet? ",
                      style: secondaryTextStyle.copyWith(fontSize: 12),
                    ),
                    Text("Sign Up", style: tncTextStyle.copyWith(fontSize: 12)),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
